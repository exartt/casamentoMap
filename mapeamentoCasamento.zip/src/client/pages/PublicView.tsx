import { useEffect, useMemo, useState } from 'react';
import type { PublicProjectResponse } from '@shared/api/schemas';
import { guestSeatMap } from '@shared/domain/seating';
import { compareNames, matchesSearch } from '@shared/domain/text';
import type { ProjectData } from '@shared/domain/types';
import { CanvasStage } from '../components/canvas/CanvasStage';
import { btn, cx, input } from '../components/common/ui';
import { formatWhen } from '../i18n/format';
import { t } from '../i18n/strings';
import { api, errorMessage } from '../persistence/apiClient';
import { getDerived } from '../store/derived';
import { useUiStore } from '../store/uiStore';

type Props = { token: string };

const MAX_RESULTS = 30;

/** Read-only page for share links: the plan plus a guest search that highlights the table. */
export function PublicView({ token }: Props) {
  const [data, setData] = useState<PublicProjectResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [highlight, setHighlight] = useState<{ tableId: string; seatIndex: number | null } | null>(null);
  const [openTable, setOpenTable] = useState<string | null>(null);
  const requestFocus = useUiStore((s) => s.requestFocus);
  const requestFit = useUiStore((s) => s.requestFit);
  const setViewport = useUiStore((s) => s.setViewport);
  const viewport = useUiStore((s) => s.viewport);

  useEffect(() => {
    api
      .getPublic(token)
      .then(setData)
      .catch((e: unknown) => setError(errorMessage(e, t.publicView.invalid)));
  }, [token]);

  const project: ProjectData | null = useMemo(() => (data ? ({ ...data.data, guests: data.data.guests } as ProjectData) : null), [data]);
  const derived = project ? getDerived(project) : null;
  const seatMap = useMemo(() => (project ? guestSeatMap(project) : new Map()), [project]);

  const results = useMemo(() => {
    if (!project || query.trim() === '') return [];
    return project.guests
      .filter((g) => matchesSearch(g.name, query))
      .sort((a, b) => compareNames(a.name, b.name))
      .slice(0, MAX_RESULTS);
  }, [project, query]);

  if (error) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-gray-100 p-6 text-center">
        <p className="text-gray-700">{error}</p>
      </main>
    );
  }
  if (!project || !derived) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-gray-100 p-6 text-center">
        <p className="text-gray-600">{t.app.loading}</p>
      </main>
    );
  }

  const openGuests = openTable ? derived.tablesById.get(openTable) : undefined;

  return (
    <div className="flex h-screen flex-col bg-gray-100">
      <header className="border-b border-gray-200 bg-white px-3 py-2">
        <div className="flex items-baseline justify-between gap-2">
          <h1 className="truncate text-base font-semibold text-gray-900">{project.name}</h1>
          <span className="shrink-0 text-xs text-gray-500">{t.publicView.updated(formatWhen(data?.savedAt ?? ''))}</span>
        </div>
        <input
          type="search"
          className={cx(input, 'mt-2')}
          placeholder={t.publicView.searchPlaceholder}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          aria-label={t.publicView.searchPlaceholder}
        />
        {query.trim() !== '' && (
          <ul className="mt-1 max-h-48 overflow-y-auto rounded-md border border-gray-200 bg-white text-sm">
            {results.length === 0 && <li className="px-3 py-2 text-gray-500">{t.publicView.noResults}</li>}
            {results.map((g) => {
              const loc = seatMap.get(g.id);
              const table = loc ? derived.tablesById.get(loc.tableId) : undefined;
              return (
                <li key={g.id}>
                  <button
                    type="button"
                    className="flex w-full items-center justify-between px-3 py-2 text-left hover:bg-brand-50"
                    onClick={() => {
                      if (loc && table) {
                        setHighlight({ tableId: table.id, seatIndex: loc.seatIndex });
                        requestFocus({ type: 'table', id: table.id }, loc.seatIndex);
                        setOpenTable(table.id);
                      }
                    }}
                  >
                    <span>{g.name}</span>
                    <span className={cx('text-xs', loc ? 'text-brand-700' : 'text-gray-500')}>
                      {loc && table ? t.publicView.seatedAt(table.label, loc.seatIndex + 1) : t.publicView.unseated}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </header>
      <div className="relative min-h-0 flex-1">
        <CanvasStage project={project} readOnly externalHighlight={highlight} onTableTap={(id) => setOpenTable(id)} />
        <div className="absolute right-2 top-2 flex flex-col gap-1">
          <button type="button" className={cx(btn.base, btn.secondary, btn.icon)} onClick={() => setViewport({ ...viewport, zoom: Math.min(4, viewport.zoom * 1.25) })} aria-label="Aproximar">
            +
          </button>
          <button type="button" className={cx(btn.base, btn.secondary, btn.icon)} onClick={() => setViewport({ ...viewport, zoom: Math.max(0.1, viewport.zoom / 1.25) })} aria-label="Afastar">
            −
          </button>
          <button type="button" className={cx(btn.base, btn.secondary, btn.icon)} onClick={requestFit} aria-label={t.topbar.fitToScreen}>
            ⤢
          </button>
        </div>
        {openGuests && (
          <div className="absolute inset-x-0 bottom-0 max-h-[45%] overflow-y-auto rounded-t-lg border-t border-gray-200 bg-white p-3 shadow-lg">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="font-semibold text-gray-900">{openGuests.label}</h2>
              <button type="button" className={cx(btn.base, btn.ghost, btn.small)} onClick={() => setOpenTable(null)} aria-label={t.app.close}>
                ×
              </button>
            </div>
            <ol className="text-sm">
              {openGuests.seats.map((seat) => {
                const guest = seat.guestId ? derived.guestsById.get(seat.guestId) : undefined;
                if (!seat.enabled) return null;
                return (
                  <li key={seat.index} className="flex gap-2 py-0.5">
                    <span className="w-6 text-right text-gray-500">{seat.index + 1}.</span>
                    <span className={guest ? '' : 'text-gray-400'}>{guest ? guest.name : t.print.emptySeat}</span>
                  </li>
                );
              })}
            </ol>
          </div>
        )}
      </div>
      <p className="bg-white px-3 py-1 text-center text-xs text-gray-500">{t.publicView.legend}</p>
    </div>
  );
}
